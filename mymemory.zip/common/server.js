const server = "";
export default server;